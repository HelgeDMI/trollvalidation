CSV_HEADER = ['reference_time', 'run_time', 'my_val']
OUTPUT_DIR = '/tmp'
TMP_DIR = '/tmp'
